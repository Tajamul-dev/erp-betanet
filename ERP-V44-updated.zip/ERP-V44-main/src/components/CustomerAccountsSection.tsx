import React, { useEffect, useRef, useState } from 'react';
import {
  Building2,
  Upload,
  FileSpreadsheet,
  FileText,
  ImageIcon,
  Loader2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Users,
} from 'lucide-react';
import { CustomerAccount } from '../types';

const STORAGE_KEY = 'gfi_customer_accounts_v1';

// Column format mirrors the physical party contract sheet:
// Party | Party Code | CBM | Contract # | Order # | Carton Qty | Other Qty |
// Address | Contact | Email | Phone | Port of Loading | Port of Discharge |
// Final Destination | Sales Pack | Items | Pending Charges
const FIELD_LABELS: Record<keyof Omit<CustomerAccount, 'id' | 'sourceFile' | 'updatedAt'>, string> = {
  partyName: 'Party Name',
  partyCode: 'Party Code',
  cbm: 'CBM',
  contractNo: 'Contract #',
  orderNo: 'Order #',
  cartonQty: 'Carton Qty',
  otherQty: 'Other Qty',
  address: 'Party Address',
  contactPerson: 'Contact Person',
  email: 'Email',
  phone: 'Phone',
  portOfLoading: 'Port of Loading',
  portOfDischarge: 'Port of Discharge',
  finalDestination: 'Final Destination',
  salesPack: 'Sales Pack',
  items: 'Items',
  pendingCharges: 'Pending Charges',
};

// Flexible header matcher for XLSX uploads
const HEADER_MAP: Array<[RegExp, keyof typeof FIELD_LABELS]> = [
  [/party\s*name|customer\s*name|party\b/i, 'partyName'],
  [/party\s*code|customer\s*code|code/i, 'partyCode'],
  [/cbm/i, 'cbm'],
  [/contract/i, 'contractNo'],
  [/order\s*(no|#|num)/i, 'orderNo'],
  [/carton\s*qty|carton\s*quantity/i, 'cartonQty'],
  [/other\s*qty|other\s*quantity/i, 'otherQty'],
  [/address/i, 'address'],
  [/contact\s*person|contact\s*name/i, 'contactPerson'],
  [/e-?mail/i, 'email'],
  [/phone|mobile|tel/i, 'phone'],
  [/port\s*of\s*loading|loading\s*port/i, 'portOfLoading'],
  [/port\s*of\s*discharge|discharge\s*port/i, 'portOfDischarge'],
  [/final\s*destination|destination/i, 'finalDestination'],
  [/sales\s*pack|packing/i, 'salesPack'],
  [/items?|products?|brand/i, 'items'],
  [/pending\s*charges?|remarks?|notes?/i, 'pendingCharges'],
];

function emptyAccount(): CustomerAccount {
  return {
    id: `acc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    partyName: '',
    partyCode: '',
    cbm: '',
    contractNo: '',
    orderNo: '',
    cartonQty: '',
    otherQty: '',
    address: '',
    contactPerson: '',
    email: '',
    phone: '',
    portOfLoading: '',
    portOfDischarge: '',
    finalDestination: '',
    salesPack: '',
    items: '',
    pendingCharges: '',
    updatedAt: new Date().toISOString(),
  };
}

function mergeAccounts(existing: CustomerAccount[], incoming: CustomerAccount[]): CustomerAccount[] {
  const next = [...existing];
  for (const inc of incoming) {
    const key = (inc.partyCode || inc.partyName || '').trim().toLowerCase();
    if (!key) continue;
    const idx = next.findIndex(a => (a.partyCode || a.partyName || '').trim().toLowerCase() === key);
    if (idx >= 0) {
      next[idx] = { ...next[idx], ...inc, id: next[idx].id, updatedAt: new Date().toISOString() };
    } else {
      next.push({ ...inc, id: `acc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}` });
    }
  }
  return next;
}

export const CustomerAccountsSection: React.FC<{ onNotify?: (msg: string) => void }> = ({ onNotify }) => {
  const [accounts, setAccounts] = useState<CustomerAccount[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });
  const [busy, setBusy] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
    } catch {}
  }, [accounts]);

  const normalize = (raw: Partial<CustomerAccount>, sourceFile: string): CustomerAccount => ({
    ...emptyAccount(),
    ...Object.fromEntries(
      Object.entries(raw).map(([k, v]) => [k, typeof v === 'string' ? v.trim() : v ?? '']),
    ),
    id: `acc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    sourceFile,
    updatedAt: new Date().toISOString(),
  } as CustomerAccount);

  const handleFiles = async (files: FileList | null) => {
    if (!files || !files.length) return;
    setBusy(true);
    setStatusMsg(null);
    let collected: CustomerAccount[] = [];

    try {
      for (const file of Array.from(files)) {
        const name = file.name;

        if (/\.(xlsx|xls|csv)$/i.test(name)) {
          const XLSX = await import('xlsx');
          const buf = await file.arrayBuffer();
          const wb = XLSX.read(buf, { type: 'array' });
          for (const sheetName of wb.SheetNames) {
            const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[sheetName], { defval: '' });
            for (const row of rows) {
              const acc = emptyAccount();
              let hasData = false;
              for (const [header, value] of Object.entries(row)) {
                if (value === '' || value == null) continue;
                const field = HEADER_MAP.find(([re]) => re.test(String(header).trim()))?.[1];
                if (field) {
                  (acc as any)[field] = String(value).trim();
                  hasData = true;
                }
              }
              if (hasData && (acc.partyName || acc.partyCode)) {
                collected.push(normalize(acc, name));
              }
            }
          }
        } else {
          // PDF or image → server-side AI extraction
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsDataURL(file);
          });
          const mimeType = file.type || (name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'image/jpeg');
          const res = await fetch('/api/scan-customer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: dataUrl, mimeType }),
          });
          if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || `Server returned ${res.status}`);
          }
          const parsed = await res.json();
          const rawAccounts: Partial<CustomerAccount>[] = Array.isArray(parsed) ? parsed : parsed.accounts || [];
          for (const raw of rawAccounts) {
            const acc = normalize(raw, name);
            if (acc.partyName || acc.partyCode) collected.push(acc);
          }
        }
      }

      if (!collected.length) {
        setStatusMsg({ kind: 'error', text: 'No customer records could be extracted from the uploaded file(s).' });
      } else {
        setAccounts(prev => mergeAccounts(prev, collected));
        setStatusMsg({
          kind: 'ok',
          text: `${collected.length} customer account${collected.length > 1 ? 's' : ''} imported and updated automatically.`,
        });
        onNotify?.(`✅ ${collected.length} customer account(s) imported.`);
      }
    } catch (err: any) {
      console.error('Customer account upload failed:', err);
      setStatusMsg({ kind: 'error', text: err.message || 'Failed to process the uploaded file.' });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400">
            <Users className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-slate-100">
              Customer Accounts
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Upload a PDF, picture, or Excel file of your party data — records are extracted and updated automatically.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <input
            ref={fileRef}
            type="file"
            multiple
            accept=".pdf,.xlsx,.xls,.csv,image/*"
            className="hidden"
            onChange={e => handleFiles(e.target.files)}
          />
          <button
            type="button"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
            className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-60 text-slate-950 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
          >
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
            <span>{busy ? 'Processing…' : 'Upload PDF / Picture / XLS'}</span>
          </button>
        </div>
      </div>

      {/* Status */}
      {statusMsg && (
        <div
          className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold border ${
            statusMsg.kind === 'ok'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200'
          }`}
        >
          {statusMsg.kind === 'ok' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Format legend */}
      <div className="flex flex-wrap gap-1.5">
        {Object.values(FIELD_LABELS).map(label => (
          <span
            key={label}
            className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[9.5px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400"
          >
            {label}
          </span>
        ))}
      </div>

      {/* Records */}
      {accounts.length === 0 ? (
        <div className="p-6 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-900/60 text-center space-y-2">
          <div className="flex items-center justify-center gap-3 text-slate-400 dark:text-slate-500">
            <FileText className="w-5 h-5" />
            <FileSpreadsheet className="w-5 h-5" />
            <ImageIcon className="w-5 h-5" />
          </div>
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            No customer accounts yet. Upload a party sheet (PDF, photo, or Excel) and the records will be created
            automatically in the format above — currently empty of names and details.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {accounts.map(acc => (
            <div
              key={acc.id}
              className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2 min-w-0">
                  <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <strong className="text-xs font-black text-slate-900 dark:text-slate-100 truncate">
                    {acc.partyName || 'Unnamed Party'}
                  </strong>
                  {acc.partyCode && (
                    <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-[9.5px] font-mono font-bold text-slate-700 dark:text-slate-200">
                      {acc.partyCode}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {acc.sourceFile && (
                    <span className="text-[9.5px] text-slate-400 font-mono truncate max-w-40" title={acc.sourceFile}>
                      {acc.sourceFile}
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => setAccounts(prev => prev.filter(a => a.id !== acc.id))}
                    className="p-1 text-rose-500 hover:text-rose-600 cursor-pointer"
                    title="Remove account"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-slate-100 dark:divide-slate-800/70">
                {(Object.keys(FIELD_LABELS) as Array<keyof typeof FIELD_LABELS>)
                  .filter(f => f !== 'partyName' && f !== 'partyCode')
                  .map(field => (
                    <div key={field} className="px-3 py-2 min-w-0">
                      <div className="text-[9px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500 truncate">
                        {FIELD_LABELS[field]}
                      </div>
                      <div
                        className={`text-[11px] font-semibold text-slate-800 dark:text-slate-200 break-words ${
                          acc[field] ? '' : 'text-slate-300 dark:text-slate-600'
                        }`}
                      >
                        {acc[field] || '—'}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
